Different model for this project file
(Just tuning some parameter, for more, just refer to the report)
1. model1.py
2. model2.py
3. model3.py
4. model4.py

Output file
1.res.txt

For more inside reading, please refer to the report.